/**
 * Adobe Helium: symbol definitions
 */
window.symbols = {
"stage": {
   version: "0.1",
   baseState: "Base State",
   initialState: "Base State",
   parameters: {

   },
   content: {
      dom: [
        {
            id:'logo',
            type:'image',
            rect:[0,0,150,150],
            fill:['rgba(0,0,0,0)','images/logoSpinNoGlowFLA.gif'],
        },
        {
            id:'city',
            type:'image',
            rect:[0,0,975,530],
            fill:['rgba(0,0,0,0)','images/cityScape.png'],
        },
        {
            id:'cityBlack',
            type:'image',
            rect:[0,0,975,193],
            fill:['rgba(0,0,0,0)','images/cityBlack.jpg'],
        },
        {
            id:'brickWall',
            type:'image',
            rect:[0,0,784,103],
            fill:['rgba(0,0,0,0)','images/brickWall_784x103.png'],
        },
        {
            id:'sign',
            type:'image',
            rect:[0,0,650,800],
            fill:['rgba(0,0,0,0)','images/motelSign_sign.gif'],
        },
        {
            id:'star1',
            type:'image',
            rect:[0,0,49,49],
            fill:['rgba(0,0,0,0)','images/star1.png'],
        },
        {
            id:'star5',
            type:'image',
            rect:[0,0,49,49],
            fill:['rgba(0,0,0,0)','images/star14.png'],
        },
        {
            id:'star2',
            type:'image',
            rect:[0,0,49,49],
            fill:['rgba(0,0,0,0)','images/star11.png'],
        },
        {
            id:'star3',
            type:'image',
            rect:[0,0,49,49],
            fill:['rgba(0,0,0,0)','images/star12.png'],
        },
        {
            id:'star4',
            type:'image',
            rect:[0,0,49,49],
            fill:['rgba(0,0,0,0)','images/star13.png'],
        },
        {
            id:'Text1',
            type:'text',
            rect:[354.99998998642,879.99995946884,0,0],
            text:"Click The Right Arrow Above",
            font:["Verdana, Geneva, sans-serif",24,"rgba(0,0,0,1)","bold","none",""],
        },
        {
            id:'Text2',
            type:'text',
            rect:[383.3333029747,943.33327245712,0,0],
            text:"And Come On I",
            align:"-webkit-auto",
            font:["Verdana, Geneva, sans-serif",24,"rgba(0,0,0,1)","bold","none","normal"],
        },
        {
            id:'Text3',
            type:'text',
            rect:[681.66664648056,948.33327245712,0,0],
            text:"n",
            align:"-webkit-auto",
            font:["Verdana, Geneva, sans-serif",36,"rgba(0,0,0,1)","bold","none","normal"],
        },
      ],
      symbolInstances: [
      ],
   },
   states: {
      "Base State": {
         "#star5": [
            ["style", "opacity", '0.5'],
            ["transform", "translateY", '131.66666px'],
            ["transform", "translateX", '191.66665px']
         ],
         "#stage": [
            ["color", "background-color", 'rgba(16,30,52,1.00)'],
            ["style", "overflow", 'hidden'],
            ["style", "height", '1250px'],
            ["style", "width", '940px']
         ],
         "#star2": [
            ["style", "opacity", '0.3'],
            ["transform", "translateY", '48.33333px'],
            ["transform", "translateX", '821.66662px']
         ],
         "#star4": [
            ["style", "opacity", '0.2'],
            ["transform", "translateY", '651.6666px'],
            ["transform", "translateX", '68.33332px']
         ],
         "#brickWall": [
            ["transform", "translateY", '1158.33325px'],
            ["transform", "translateX", '81.66668px']
         ],
         "#logo": [
            ["transform", "scaleX", '1.2'],
            ["transform", "translateY", '87px'],
            ["transform", "scaleY", '1.2'],
            ["transform", "translateX", '575px']
         ],
         "#star3": [
            ["style", "opacity", '0.3'],
            ["transform", "translateY", '686.66662px'],
            ["transform", "translateX", '831.6666px']
         ],
         "#cityBlack": [
            ["transform", "translateX", '-40px'],
            ["transform", "translateY", '1063.33333px']
         ],
         "#city": [
            ["transform", "translateY", '556.66664px'],
            ["transform", "translateX", '-29.66663px']
         ],
         "#star1": [
            ["style", "opacity", '0.47058823529412'],
            ["transform", "translateY", '299.99999px'],
            ["transform", "translateX", '454.99995px']
         ],
         "#sign": [
            ["transform", "scaleX", '1.2'],
            ["transform", "scaleY", '1.2'],
            ["transform", "translateY", '287px'],
            ["transform", "translateX", '145px']
         ],
         "#Text3": [
            ["transform", "translateX", '-11px'],
            ["transform", "translateY", '-26px'],
            ["transform", "rotateZ", '30deg']
         ],
         "#Text2": [
            ["transform", "translateY", '-23.33332px'],
            ["transform", "translateX", '-25px'],
            ["style", "font-size", '36px']
         ],
         "#Text1": [
            ["style", "font-family", 'Verdana, Geneva, sans-serif'],
            ["transform", "translateY", '-4.66669px'],
            ["transform", "translateX", '-14.6667px']
         ]
      }
   },
   actions: {

   },
   bindings: [

   ],
   timelines: {
      "Default Timeline": {
         fromState: "Base State",
         toState: "",
         duration: 1578000,
         timeline: [
            { id: "eid148", tween: [ "style", "#star3", "opacity", '0.3', { valueTemplate: undefined, fromValue: '0.3'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid173", tween: [ "style", "#star3", "opacity", '0.5', { valueTemplate: undefined, fromValue: '0.3'}], position: 456000, duration: 36000, easing: "linear" },
            { id: "eid174", tween: [ "style", "#star3", "opacity", '0.3', { valueTemplate: undefined, fromValue: '0.5'}], position: 492000, duration: 32000, easing: "linear" },
            { id: "eid175", tween: [ "style", "#star3", "opacity", '0.5', { valueTemplate: undefined, fromValue: '0.3'}], position: 1510000, duration: 36000, easing: "linear" },
            { id: "eid176", tween: [ "style", "#star3", "opacity", '0.3', { valueTemplate: undefined, fromValue: '0.5'}], position: 1546000, duration: 32000, easing: "linear" },
            { id: "eid163", tween: [ "transform", "#star4", "translateX", '68.33332px', { valueTemplate: undefined, fromValue: '68.33332px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid17", tween: [ "transform", "#sign", "scaleX", '1.2', { valueTemplate: undefined, fromValue: '1.2'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid166", tween: [ "transform", "#star1", "translateX", '454.99995px', { valueTemplate: undefined, fromValue: '454.99995px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid18", tween: [ "transform", "#sign", "scaleY", '1.2', { valueTemplate: undefined, fromValue: '1.2'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid142", tween: [ "style", "#star1", "opacity", '0.47058823529412', { valueTemplate: undefined, fromValue: '0.47058823529412'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid146", tween: [ "transform", "#star3", "translateX", '831.6666px', { valueTemplate: undefined, fromValue: '831.6666px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid160", tween: [ "transform", "#cityBlack", "translateY", '1063.33333px', { valueTemplate: undefined, fromValue: '1063.33333px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid131", tween: [ "transform", "#brickWall", "translateY", '1158.33325px', { valueTemplate: undefined, fromValue: '1158.33325px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid143", tween: [ "transform", "#star2", "translateX", '821.66662px', { valueTemplate: undefined, fromValue: '821.66662px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid130", tween: [ "transform", "#brickWall", "translateX", '81.66668px', { valueTemplate: undefined, fromValue: '81.66668px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid169", tween: [ "transform", "#star5", "translateY", '131.66666px', { valueTemplate: undefined, fromValue: '131.66666px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid187", tween: [ "style", "#Text2", "font-size", '36px', { valueTemplate: undefined, fromValue: '36px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid137", tween: [ "transform", "#logo", "translateY", '87px', { valueTemplate: undefined, fromValue: '87px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid139", tween: [ "color", "#stage", "background-color", 'rgba(16,30,52,1.00)', { animationColorSpace: 'RGB', valueTemplate: undefined, fromValue: 'rgba(16,30,52,1.00)'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid144", tween: [ "transform", "#star2", "translateY", '48.33333px', { valueTemplate: undefined, fromValue: '48.33333px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid205", tween: [ "transform", "#Text3", "translateX", '-11px', { valueTemplate: undefined, fromValue: '-11px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid201", tween: [ "transform", "#Text3", "translateY", '-26px', { valueTemplate: undefined, fromValue: '-26px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid76", tween: [ "transform", "#sign", "translateX", '145px', { valueTemplate: undefined, fromValue: '145px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid145", tween: [ "style", "#star2", "opacity", '0.3', { valueTemplate: undefined, fromValue: '0.3'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid89", tween: [ "style", "#stage", "height", '1250px', { valueTemplate: undefined, fromValue: '1250px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid170", tween: [ "style", "#star5", "opacity", '0.5', { valueTemplate: undefined, fromValue: '0.5'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid179", tween: [ "style", "#star5", "opacity", '1', { valueTemplate: undefined, fromValue: '0.5'}], position: 150000, duration: 50000, easing: "linear" },
            { id: "eid180", tween: [ "style", "#star5", "opacity", '0.5', { valueTemplate: undefined, fromValue: '1'}], position: 200000, duration: 26000, easing: "linear" },
            { id: "eid23", tween: [ "transform", "#logo", "scaleY", '1.2', { valueTemplate: undefined, fromValue: '1.2'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid161", tween: [ "transform", "#city", "translateX", '-29.66663px', { valueTemplate: undefined, fromValue: '-29.66663px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid75", tween: [ "transform", "#logo", "translateX", '575px', { valueTemplate: undefined, fromValue: '575px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid198", tween: [ "transform", "#Text3", "rotateZ", '30deg', { valueTemplate: undefined, fromValue: '30deg'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid167", tween: [ "transform", "#star1", "translateY", '299.99999px', { valueTemplate: undefined, fromValue: '299.99999px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid147", tween: [ "transform", "#star3", "translateY", '686.66662px', { valueTemplate: undefined, fromValue: '686.66662px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid159", tween: [ "transform", "#cityBlack", "translateX", '-40px', { valueTemplate: undefined, fromValue: '-40px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid136", tween: [ "transform", "#sign", "translateY", '287px', { valueTemplate: undefined, fromValue: '287px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid189", tween: [ "transform", "#Text2", "translateY", '-23.33332px', { valueTemplate: undefined, fromValue: '-23.33332px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid22", tween: [ "transform", "#logo", "scaleX", '1.2', { valueTemplate: undefined, fromValue: '1.2'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid164", tween: [ "transform", "#star4", "translateY", '651.6666px', { valueTemplate: undefined, fromValue: '651.6666px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid162", tween: [ "transform", "#city", "translateY", '556.66664px', { valueTemplate: undefined, fromValue: '556.66664px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid168", tween: [ "transform", "#star5", "translateX", '191.66665px', { valueTemplate: undefined, fromValue: '191.66665px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid212", tween: [ "transform", "#Text1", "translateX", '-14.6667px', { valueTemplate: undefined, fromValue: '-14.6667px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid209", tween: [ "transform", "#Text1", "translateY", '-4.66669px', { valueTemplate: undefined, fromValue: '-4.66669px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid203", tween: [ "transform", "#Text2", "translateX", '-25px', { valueTemplate: undefined, fromValue: '-25px'}], position: 0, duration: 0, easing: "linear" },
            { id: "eid151", tween: [ "style", "#star4", "opacity", '0.2', { valueTemplate: undefined, fromValue: '0.2'}], position: 0, duration: 0, easing: "linear" }]
      }
   },
}};

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     $.Edge.initialize(symbols);
});
/**
 * Adobe Edge Timeline Launch
 */
$(window).load(function() {
    $.Edge.play();
});
